/*
 * serve_home.c -- implementation of the serve-home client. See serve_home.h
 * for the threading model and protocol overview.
 */

#include "serve_home.h"
#include "serve_home_config.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/event_groups.h"

#include "esp_timer.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_http_client.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "cJSON.h"

static const char *TAG = "serve_home";

/* ---- endpoint paths ---- */
#define EP_ENROLL     "/api/device/enroll"
#define EP_HEARTBEAT  "/api/device/heartbeat"
#define EP_CONFIG     "/api/device/config"
#define EP_SCAN       "/api/device/scan"

/* ---- runtime state ---- */
static QueueHandle_t s_scan_queue   = NULL;   /* serve_home_scan_t            */
static QueueHandle_t s_action_queue = NULL;   /* serve_home_action_t          */
static EventGroupHandle_t s_wifi_events = NULL;
#define WIFI_CONNECTED_BIT BIT0

static char s_device_token[96] = {0};         /* bearer token after enroll    */
static volatile int  s_config_version = -1;    /* last config version we hold   */

/* Per-reader config, as last configured on the dashboard. One entry per
 * reader (PD) the server lists for this controller; looked up by
 * (osdpAddress, readerNo). Written by the network task, read by the OSDP
 * task, so every access goes through s_cfg_mux. Defaults below apply to a
 * reader the dashboard doesn't know about (and before the first fetch). */
typedef struct {
    bool     used;
    int      address;            /* OSDP bus address                      */
    int      reader_no;          /* reader index within that PD           */
    int      idle_color;         /* OSDP_LED_COLOR_* value (server 0..7)  */
    int      grant_color;
    bool     grant_flashing;
    uint16_t grant_hold_ds;
    uint8_t  grant_flash_on_ds;
    uint8_t  grant_flash_off_ds;
    uint16_t grant_unlock_ds;
} reader_cfg_t;

static const reader_cfg_t DEFAULT_CFG = {
    .used = false, .address = 0, .reader_no = 0,
    .idle_color = 4,             /* OSDP_LED_COLOR_BLUE  */
    .grant_color = 2,            /* OSDP_LED_COLOR_GREEN */
    .grant_flashing = false,
    .grant_hold_ds = 30,         /* 3.0 s */
    .grant_flash_on_ds = 3,
    .grant_flash_off_ds = 3,
    .grant_unlock_ds = 50,       /* 5.0 s */
};
static reader_cfg_t s_readers[SERVE_HOME_MAX_READERS];
static portMUX_TYPE s_cfg_mux = portMUX_INITIALIZER_UNLOCKED;

static char s_wifi_ssid[33] = SERVE_HOME_WIFI_SSID;
static char s_wifi_pass[65] = SERVE_HOME_WIFI_PASSWORD;
static char s_enroll_key[65] = SERVE_HOME_ENROLL_KEY;

/* ================================================================
 * NVS: optional provisioning overrides + token persistence
 * ================================================================ */

static void load_nvs_overrides(void)
{
    nvs_handle_t h;
    if (nvs_open("serve_home", NVS_READWRITE, &h) != ESP_OK) {
        return;
    }
    size_t len;

    len = sizeof(s_wifi_ssid);
    nvs_get_str(h, "wifi_ssid", s_wifi_ssid, &len);
    len = sizeof(s_wifi_pass);
    nvs_get_str(h, "wifi_pass", s_wifi_pass, &len);
    len = sizeof(s_enroll_key);
    nvs_get_str(h, "enroll_key", s_enroll_key, &len);
    len = sizeof(s_device_token);
    if (nvs_get_str(h, "dev_token", s_device_token, &len) == ESP_OK && s_device_token[0]) {
        ESP_LOGI(TAG, "loaded device token from NVS (already enrolled)");
    }
    nvs_close(h);
}

static void persist_token(void)
{
    nvs_handle_t h;
    if (nvs_open("serve_home", NVS_READWRITE, &h) != ESP_OK) {
        return;
    }
    nvs_set_str(h, "dev_token", s_device_token);
    nvs_commit(h);
    nvs_close(h);
}

/* ================================================================
 * WiFi (STA)
 * ================================================================ */

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        xEventGroupClearBits(s_wifi_events, WIFI_CONNECTED_BIT);
        ESP_LOGW(TAG, "WiFi disconnected, retrying");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "WiFi connected, IP " IPSTR, IP2STR(&e->ip_info.ip));
        xEventGroupSetBits(s_wifi_events, WIFI_CONNECTED_BIT);
    }
}

static void wifi_start(void)
{
    s_wifi_events = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                        wifi_event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP,
                                                        wifi_event_handler, NULL, NULL));

    wifi_config_t wc = {0};
    strlcpy((char *)wc.sta.ssid, s_wifi_ssid, sizeof(wc.sta.ssid));
    strlcpy((char *)wc.sta.password, s_wifi_pass, sizeof(wc.sta.password));
    wc.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wc));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG, "WiFi starting, joining \"%s\"", s_wifi_ssid);
}

/* ================================================================
 * HTTP helper: POST/GET JSON, accumulate body into caller buffer
 * ================================================================ */

typedef struct {
    char  *buf;
    int    cap;
    int    len;
} http_accum_t;

static esp_err_t http_evt(esp_http_client_event_t *evt)
{
    if (evt->event_id == HTTP_EVENT_ON_DATA && evt->user_data) {
        http_accum_t *a = (http_accum_t *)evt->user_data;
        int n = evt->data_len;
        if (a->len + n > a->cap - 1) {
            n = a->cap - 1 - a->len;    /* truncate rather than overflow */
        }
        if (n > 0) {
            memcpy(a->buf + a->len, evt->data, n);
            a->len += n;
            a->buf[a->len] = '\0';
        }
    }
    return ESP_OK;
}

/*
 * Perform an HTTP request. `body` may be NULL for GET. Response JSON (if any)
 * is written into resp/resp_cap. Returns the HTTP status code, or -1 on a
 * transport error.
 */
static int http_json(const char *path, esp_http_client_method_t method,
                     const char *body, bool with_auth, char *resp, int resp_cap)
{
    char url[256];
    snprintf(url, sizeof(url), "%s%s", SERVE_HOME_URL, path);

    http_accum_t accum = { .buf = resp, .cap = resp_cap, .len = 0 };
    if (resp && resp_cap > 0) {
        resp[0] = '\0';
    }

    esp_http_client_config_t cfg = {
        .url = url,
        .method = method,
        .timeout_ms = SERVE_HOME_HTTP_TIMEOUT_MS,
        .event_handler = http_evt,
        .user_data = (resp && resp_cap > 0) ? &accum : NULL,
        /* For an https:// SERVE_HOME_URL, attach your CA here, e.g.
         *   .cert_pem = server_root_ca_pem_start,
         * or set .crt_bundle_attach = esp_crt_bundle_attach with the
         * certificate-bundle component enabled. Plain http is fine on an
         * isolated bench network. */
    };

    esp_http_client_handle_t c = esp_http_client_init(&cfg);
    if (!c) {
        return -1;
    }
    esp_http_client_set_header(c, "Content-Type", "application/json");
    if (with_auth && s_device_token[0]) {
        char auth[128];
        snprintf(auth, sizeof(auth), "Bearer %s", s_device_token);
        esp_http_client_set_header(c, "Authorization", auth);
    }
    if (body) {
        esp_http_client_set_post_field(c, body, strlen(body));
    }

    int status = -1;
    esp_err_t err = esp_http_client_perform(c);
    if (err == ESP_OK) {
        status = esp_http_client_get_status_code(c);
    } else {
        ESP_LOGW(TAG, "HTTP %s %s failed: %s", path,
                 method == HTTP_METHOD_GET ? "GET" : "POST", esp_err_to_name(err));
    }
    esp_http_client_cleanup(c);
    return status;
}

/* ================================================================
 * Protocol steps
 * ================================================================ */

/* Look up a reader's config by (address, reader_no). An exact match wins; else
 * the first entry with the same address (mirrors the server's findReader());
 * else the defaults. Returns a copy so callers never hold the lock. */
static reader_cfg_t lookup_cfg(int address, int reader_no)
{
    reader_cfg_t out = DEFAULT_CFG;
    out.address = address;
    out.reader_no = reader_no;

    portENTER_CRITICAL(&s_cfg_mux);
    int exact = -1, loose = -1;
    for (int i = 0; i < SERVE_HOME_MAX_READERS; i++) {
        if (s_readers[i].used && s_readers[i].address == address) {
            if (s_readers[i].reader_no == reader_no) {
                exact = i;
                break;
            }
            if (loose < 0) {
                loose = i;
            }
        }
    }
    int pick = (exact >= 0) ? exact : loose;
    if (pick >= 0) {
        out = s_readers[pick];
    }
    portEXIT_CRITICAL(&s_cfg_mux);
    return out;
}

/* Shared by do_enroll() and do_fetch_config(): both responses carry the same
 * readers[] bundle (see buildReaderConfig() in the dashboard's enroll.ts).
 * Builds a fresh table from EVERY reader, then swaps it in atomically so the
 * OSDP task never sees a half-updated table. A reader deleted on the
 * dashboard disappears from the table (back to defaults). */
static void parse_reader_bundle(cJSON *readers)
{
    reader_cfg_t next[SERVE_HOME_MAX_READERS];
    memset(next, 0, sizeof(next));
    int n = 0;
    int count = cJSON_GetArraySize(readers);
    if (count > SERVE_HOME_MAX_READERS) {
        ESP_LOGW(TAG, "server lists %d readers, only the first %d are used",
                 count, SERVE_HOME_MAX_READERS);
    }

    for (int i = 0; i < count && n < SERVE_HOME_MAX_READERS; i++) {
        cJSON *r = cJSON_GetArrayItem(readers, i);
        if (!cJSON_IsObject(r)) {
            continue;
        }
        reader_cfg_t c = DEFAULT_CFG;
        c.used = true;
        cJSON *v;

        v = cJSON_GetObjectItem(r, "osdpAddress");
        if (cJSON_IsNumber(v)) c.address = v->valueint;
        v = cJSON_GetObjectItem(r, "readerNo");
        if (cJSON_IsNumber(v)) c.reader_no = v->valueint;
        v = cJSON_GetObjectItem(r, "idleColor");
        if (cJSON_IsNumber(v)) c.idle_color = v->valueint;
        v = cJSON_GetObjectItem(r, "grantColor");
        if (cJSON_IsNumber(v)) c.grant_color = v->valueint;
        v = cJSON_GetObjectItem(r, "grantPattern");
        if (cJSON_IsString(v)) c.grant_flashing = (strcmp(v->valuestring, "flashing") == 0);

        /* The dashboard sends grantHoldMs / unlockDurationMs. (The earlier
         * firmware looked for holdMs / unlockMs, which never matched, so the
         * hold and unlock times from the dashboard were silently ignored.
         * The old names are still accepted as a fallback.) */
        v = cJSON_GetObjectItem(r, "grantHoldMs");
        if (!cJSON_IsNumber(v)) v = cJSON_GetObjectItem(r, "holdMs");
        if (cJSON_IsNumber(v)) c.grant_hold_ds = (uint16_t)(v->valueint / 100);
        v = cJSON_GetObjectItem(r, "flashOnDs");
        if (cJSON_IsNumber(v)) c.grant_flash_on_ds = (uint8_t)v->valueint;
        v = cJSON_GetObjectItem(r, "flashOffDs");
        if (cJSON_IsNumber(v)) c.grant_flash_off_ds = (uint8_t)v->valueint;
        v = cJSON_GetObjectItem(r, "unlockDurationMs");
        if (!cJSON_IsNumber(v)) v = cJSON_GetObjectItem(r, "unlockMs");
        if (cJSON_IsNumber(v)) c.grant_unlock_ds = (uint16_t)(v->valueint / 100);

        next[n++] = c;
        ESP_LOGI(TAG, "config: reader addr=%d no=%d idle=%d grant=%d %s hold=%dds flash=%d/%dds unlock=%dds",
                 c.address, c.reader_no, c.idle_color, c.grant_color,
                 c.grant_flashing ? "flash" : "solid", c.grant_hold_ds,
                 c.grant_flash_on_ds, c.grant_flash_off_ds, c.grant_unlock_ds);
    }

    portENTER_CRITICAL(&s_cfg_mux);
    memcpy(s_readers, next, sizeof(s_readers));
    portEXIT_CRITICAL(&s_cfg_mux);
}

static bool do_enroll(void)
{
    cJSON *req = cJSON_CreateObject();
    cJSON_AddStringToObject(req, "enrollKey", s_enroll_key);
    cJSON_AddStringToObject(req, "firmwareVersion", "serve-home-1.0");
    cJSON_AddStringToObject(req, "wifiSsid", s_wifi_ssid);
    char *body = cJSON_PrintUnformatted(req);
    cJSON_Delete(req);

    static char resp[4096];   /* room for several readers; task-only, so static is safe */
    int status = http_json(EP_ENROLL, HTTP_METHOD_POST, body, false, resp, sizeof(resp));
    free(body);

    if (status != 200) {
        ESP_LOGW(TAG, "enroll failed (HTTP %d)", status);
        return false;
    }

    cJSON *root = cJSON_Parse(resp);
    if (!root) {
        return false;
    }
    cJSON *tok = cJSON_GetObjectItem(root, "deviceToken");
    bool ok = false;
    if (cJSON_IsString(tok) && tok->valuestring[0]) {
        strlcpy(s_device_token, tok->valuestring, sizeof(s_device_token));
        persist_token();
        ok = true;
        ESP_LOGI(TAG, "enrolled; device token acquired");
    }
    /* enroll also returns the reader config bundle -- capture all readers. */
    cJSON *readers = cJSON_GetObjectItem(root, "readers");
    if (cJSON_IsArray(readers)) {
        parse_reader_bundle(readers);
    }
    cJSON *cv = cJSON_GetObjectItem(root, "configVersion");
    if (cJSON_IsNumber(cv)) {
        s_config_version = cv->valueint;
    }
    cJSON_Delete(root);
    return ok;
}

static void do_fetch_config(void)
{
    static char resp[4096];   /* room for several readers; task-only, so static is safe */
    int status = http_json(EP_CONFIG, HTTP_METHOD_GET, NULL, true, resp, sizeof(resp));
    if (status != 200) {
        ESP_LOGW(TAG, "config fetch failed (HTTP %d)", status);
        return;
    }
    cJSON *root = cJSON_Parse(resp);
    if (!root) {
        return;
    }
    cJSON *readers = cJSON_GetObjectItem(root, "readers");
    if (cJSON_IsArray(readers)) {
        parse_reader_bundle(readers);
    }
    cJSON_Delete(root);
}

/* Heartbeat; returns the server's configVersion (or -1 on failure). */
static int do_heartbeat(void)
{
    wifi_ap_record_t ap;
    int rssi = (esp_wifi_sta_get_ap_info(&ap) == ESP_OK) ? ap.rssi : 0;

    cJSON *req = cJSON_CreateObject();
    cJSON_AddNumberToObject(req, "rssi", rssi);
    char *body = cJSON_PrintUnformatted(req);
    cJSON_Delete(req);

    char resp[512];
    int status = http_json(EP_HEARTBEAT, HTTP_METHOD_POST, body, true, resp, sizeof(resp));
    free(body);

    if (status == 401) {
        /* token was revoked (key rotated) -- force re-enroll */
        ESP_LOGW(TAG, "heartbeat unauthorized; clearing token to re-enroll");
        s_device_token[0] = '\0';
        persist_token();
        return -1;
    }
    if (status != 200) {
        return -1;
    }
    int cv = -1;
    cJSON *root = cJSON_Parse(resp);
    if (root) {
        cJSON *v = cJSON_GetObjectItem(root, "configVersion");
        if (cJSON_IsNumber(v)) {
            cv = v->valueint;
        }
        cJSON_Delete(root);
    }
    return cv;
}

/* Report one card read; fill *action from the server's decision. */
static bool do_report_scan(const serve_home_scan_t *scan, serve_home_action_t *action)
{
    /* Encode the raw card bytes as a hex string; the server decodes FC/CN. */
    char hex[2 * SERVE_HOME_MAX_CARD_BYTES + 1] = {0};
    int pos = 0;
    for (int i = 0; i < scan->data_len && i < SERVE_HOME_MAX_CARD_BYTES; i++) {
        pos += snprintf(hex + pos, sizeof(hex) - pos, "%02x", scan->data[i]);
    }

    cJSON *req = cJSON_CreateObject();
    cJSON_AddNumberToObject(req, "osdpAddress", scan->osdp_address);
    cJSON_AddNumberToObject(req, "osdpReaderNo", scan->reader_no);
    cJSON_AddStringToObject(req, "raw", hex);
    cJSON_AddNumberToObject(req, "bitFormat", SERVE_HOME_BIT_FORMAT);
    cJSON_AddNumberToObject(req, "lengthBits", scan->length_bits);
    char *body = cJSON_PrintUnformatted(req);
    cJSON_Delete(req);

    char resp[1024];
    int status = http_json(EP_SCAN, HTTP_METHOD_POST, body, true, resp, sizeof(resp));
    free(body);

    if (status != 200) {
        ESP_LOGW(TAG, "scan report failed (HTTP %d)", status);
        return false;
    }

    cJSON *root = cJSON_Parse(resp);
    if (!root) {
        return false;
    }

    memset(action, 0, sizeof(*action));
    action->valid = true;
    action->osdp_address = scan->osdp_address;
    action->reader_no = scan->reader_no;
    action->idle_color = lookup_cfg(scan->osdp_address, scan->reader_no).idle_color;

    cJSON *grant = cJSON_GetObjectItem(root, "grant");
    action->grant = cJSON_IsTrue(grant);

    cJSON *led = cJSON_GetObjectItem(root, "led");
    if (cJSON_IsObject(led)) {
        cJSON *color = cJSON_GetObjectItem(led, "color");
        cJSON *pattern = cJSON_GetObjectItem(led, "pattern");
        cJSON *holdMs = cJSON_GetObjectItem(led, "holdMs");
        cJSON *onDs = cJSON_GetObjectItem(led, "flashOnDs");
        cJSON *offDs = cJSON_GetObjectItem(led, "flashOffDs");
        cJSON *idle = cJSON_GetObjectItem(led, "idleColor");
        if (cJSON_IsNumber(color))  action->led_color = color->valueint;
        if (cJSON_IsString(pattern)) action->flashing = (strcmp(pattern->valuestring, "flashing") == 0);
        if (cJSON_IsNumber(holdMs)) action->hold_ds = (uint16_t)(holdMs->valueint / 100);
        if (cJSON_IsNumber(onDs))   action->flash_on_ds = (uint8_t)onDs->valueint;
        if (cJSON_IsNumber(offDs))  action->flash_off_ds = (uint8_t)offDs->valueint;
        if (cJSON_IsNumber(idle))   action->idle_color = idle->valueint;
    }
    if (action->hold_ds == 0) {
        action->hold_ds = 10;   /* sane 1.0s default */
    }

    cJSON *beep = cJSON_GetObjectItem(root, "beep");
    action->beep = cJSON_IsTrue(beep);

    cJSON *unlockMs = cJSON_GetObjectItem(root, "unlockMs");
    if (cJSON_IsNumber(unlockMs)) {
        action->unlock_ds = (uint16_t)(unlockMs->valueint / 100);
    }

    cJSON_Delete(root);
    ESP_LOGI(TAG, "scan -> %s (led=%d %s, unlock=%dds)",
             action->grant ? "GRANT" : "DENY", action->led_color,
             action->flashing ? "flash" : "solid", action->unlock_ds);
    return true;
}

/* ================================================================
 * Network task
 * ================================================================ */

static void serve_home_task(void *arg)
{
    (void)arg;
    /* wait for WiFi before doing anything network-y */
    xEventGroupWaitBits(s_wifi_events, WIFI_CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY);

    int64_t next_hb = 0;
    const TickType_t poll = pdMS_TO_TICKS(50);

    while (1) {
        /* make sure we still have WiFi */
        EventBits_t bits = xEventGroupGetBits(s_wifi_events);
        if (!(bits & WIFI_CONNECTED_BIT)) {
            xEventGroupWaitBits(s_wifi_events, WIFI_CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY);
        }

        /* make sure we're enrolled */
        if (!s_device_token[0]) {
            if (!do_enroll()) {
                vTaskDelay(pdMS_TO_TICKS(3000));
                continue;
            }
            do_fetch_config();
        }

        /* drain any pending card reads first (lowest latency for the user) */
        serve_home_scan_t scan;
        while (xQueueReceive(s_scan_queue, &scan, 0) == pdTRUE) {
            serve_home_action_t action;
            if (do_report_scan(&scan, &action)) {
                xQueueSend(s_action_queue, &action, 0);
            }
        }

        /* periodic heartbeat + config refresh on version change */
        int64_t now = esp_timer_get_time() / 1000;
        if (now >= next_hb) {
            next_hb = now + SERVE_HOME_HEARTBEAT_SEC * 1000;
            int cv = do_heartbeat();
            if (cv >= 0 && cv != s_config_version) {
                ESP_LOGI(TAG, "config version %d -> %d, refreshing", s_config_version, cv);
                s_config_version = cv;
                do_fetch_config();
            }
        }

        /* Block briefly on the scan queue so a fresh read wakes us promptly
         * without busy-spinning between heartbeats. */
        if (xQueuePeek(s_scan_queue, &scan, poll) == pdTRUE) {
            continue;   /* something arrived -- loop to drain it now */
        }
    }
}

/* ================================================================
 * Public API
 * ================================================================ */

void serve_home_start(void)
{
    esp_err_t nvs = nvs_flash_init();
    if (nvs == ESP_ERR_NVS_NO_FREE_PAGES || nvs == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    load_nvs_overrides();

    s_scan_queue   = xQueueCreate(8, sizeof(serve_home_scan_t));
    s_action_queue = xQueueCreate(8, sizeof(serve_home_action_t));

    wifi_start();

    /* Bigger stack: TLS + JSON parsing are stack-hungry. */
    xTaskCreate(serve_home_task, "serve_home", 8192, NULL, 5, NULL);
}

bool serve_home_submit_scan(const serve_home_scan_t *scan)
{
    if (!s_scan_queue) {
        return false;
    }
    return xQueueSend(s_scan_queue, scan, 0) == pdTRUE;
}

bool serve_home_poll_action(serve_home_action_t *out)
{
    if (!s_action_queue) {
        return false;
    }
    return xQueueReceive(s_action_queue, out, 0) == pdTRUE;
}

int serve_home_idle_color(int osdp_address, int reader_no)
{
    return lookup_cfg(osdp_address, reader_no).idle_color;
}

void serve_home_get_grant_defaults(int osdp_address, int reader_no,
                                   serve_home_grant_defaults_t *out)
{
    if (!out) {
        return;
    }
    reader_cfg_t c = lookup_cfg(osdp_address, reader_no);
    out->led_color    = c.grant_color;
    out->flashing     = c.grant_flashing;
    out->hold_ds      = c.grant_hold_ds;
    out->flash_on_ds  = c.grant_flash_on_ds;
    out->flash_off_ds = c.grant_flash_off_ds;
    out->unlock_ds    = c.grant_unlock_ds;
}

bool serve_home_is_enrolled(void)
{
    return s_device_token[0] != '\0';
}