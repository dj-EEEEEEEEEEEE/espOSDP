/*
 * OSDP Control Panel (CP) test app for the HID R10 iCLASS SE reader,
 * built against the official ESP-IDF LibOSDP component (osdp-dev/libosdp).
 *
 * RS485 wiring (ALMOCN auto-direction adapter, no DE/RE pin to manage):
 *   - RS485 board TX -> ESP32 GPIO 14  (this is the ESP32's UART RX)
 *   - RS485 board RX -> ESP32 GPIO 27  (this is the ESP32's UART TX)
 *
 * Unlock relay signal (added):
 *   - ESP32 GPIO 13 -> relay driver input. Driven HIGH (3.3V) whenever
 *     the door should be unlocked; LOW otherwise.
 *   - GPIO25 is driven HIGH continuously; GPIO26 is an input with an
 *     internal pull-down, so it only reads HIGH while physically shorted
 *     to GPIO25 (a manual override / REX button wired across those two
 *     pins). Bridging them is edge-detected and simulates a fully granted
 *     card scan -- same LED/beep/relay/door-strike sequence as a real
 *     grant from serve_home, using the reader's configured grant presentation
 *     and unlock time (serve_home_get_grant_defaults(), last fetched from the
 *     dashboard) rather than local firmware constants -- so a manual trigger
 *     stays unlocked for exactly as long as the webconfig's grant unlock
 *     time says, same as a real card grant.
 *   - Beep length is defined in this file as a plain millisecond value
 *     (BEEP_ON_MS / BEEP_OFF_MS) and converted to OSDP's 100ms buzzer
 *     units internally -- edit those two constants to change how long
 *     the reader beeps, for both server-driven grants and manual triggers.
 *
 * This brings up OSDP_NUM_PDS readers (PDs) on ONE shared RS485 bus, each at
 * its own OSDP address (PD_ADDRESS below), at OSDP_UART_BAUD,
 * no secure channel (scbk = NULL) to start with -- get plaintext polling
 * and card reads working first, then layer on Secure Channel/AES once
 * basic comms are confirmed.
 *
 * SERVE-HOME: card reads are forwarded to the OSDP XCS dashboard, which
 * makes the access decision and returns the LED / buzzer / door-strike
 * behavior to apply. All HTTP happens on a separate task (serve_home.c);
 * this file only enqueues reads and applies decisions in the refresh loop.
 */

#include <string.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"

#include "osdp.h"
#include "serve_home.h"

static const char *TAG = "osdp_r10";

// ---- RS485 UART wiring ----
#define OSDP_UART_PORT      UART_NUM_2
#define OSDP_UART_RX_PIN    14   // board TX -> here
#define OSDP_UART_TX_PIN    27   // board RX -> here
#define OSDP_UART_BAUD      115200
#define OSDP_UART_BUF_SIZE  256

// ---- Unlock relay + manual bridge-override GPIOs ----
#define UNLOCK_RELAY_GPIO   GPIO_NUM_13   // output: HIGH = unlock active
#define BRIDGE_DRIVE_GPIO   GPIO_NUM_25   // output: held HIGH continuously
#define BRIDGE_SENSE_GPIO   GPIO_NUM_26   // input, pull-down: HIGH when bridged to 25

// ---- Readers (PDs) on the shared RS485 bus -------------------------------
// OSDP is multi-drop: every reader sits on the same A/B pair and answers only
// to its own address. Add one PD_ADDRESS entry per reader, set the SAME address
// on the reader itself, and enter the same address on the dashboard's reader
// page. Addresses must be unique (0..126). Keep OSDP_NUM_PDS <= OSDP_PD_MAX
// (menuconfig -> Component config -> OSDP).
#define OSDP_NUM_PDS        2
static const int PD_ADDRESS[OSDP_NUM_PDS] = { 0, 1 };

// Local relay output driven when THAT reader grants access (-1 = none, only
// the reader's own OSDP output pulses). Two readers on one door (entry/exit):
// give both the same pin. Two separate doors: give each its own pin.
// PD address 0 has no local relay; PD address 1 drives the local relay on GPIO13.
static const int PD_RELAY_GPIO[OSDP_NUM_PDS] = { -1, UNLOCK_RELAY_GPIO };

// The GPIO25/26 manual bridge simulates a grant on this PD index.
#define BRIDGE_PD           0

// ---- Beep timing, in plain milliseconds ----
// Edit these two to change how long/how the reader beeps. They're used for
// BOTH a server-driven grant/deny beep and the manual bridge-trigger beep.
// Converted internally to OSDP's buzzer on/off counts (units of 100ms).
#define BEEP_ON_MS           300   // length of a single beep pulse, in ms
#define BEEP_OFF_MS          300   // silent gap between repeated beeps, in ms

// ---------------------------------------------------------------
// Secure Channel Base Key (SCBK) -- the permanent AES-128 key this CP
// will install on the R10.
//
// THIS IS A BENCH-TESTING PLACEHOLDER. Before any real deployment,
// replace this with a genuinely random key (e.g. esp_fill_random())
// generated once and persisted in NVS -- never checked into source
// alongside a fielded device. Anyone with this key can decrypt/forge
// OSDP traffic to the reader.
static const uint8_t r10_scbk[16] = {
    0x9F, 0x2A, 0x71, 0xC3, 0x5E, 0x8B, 0x14, 0xD6,
    0x47, 0xA0, 0xB9, 0x3C, 0x62, 0xE5, 0x1F, 0x8A,
};

// ---- LED colors ----
#define IDLE_LED_COLOR   OSDP_LED_COLOR_BLUE
#define SCAN_LED_COLOR   OSDP_LED_COLOR_GREEN

// Forward declarations -- defined below, used by cp_event_cb() above them.
// `pd` is the PD index (position in PD_ADDRESS); `reader` is the reader number
// within that PD (almost always 0).
static void osdp_flash_led(int pd, int reader, int on_color, int off_color,
                            uint8_t on_ds, uint8_t off_ds, uint16_t duration_ds);
static void osdp_beep(int pd, int reader, uint8_t on_ds, uint8_t off_ds, uint8_t reps);
static void osdp_beep_ms(int pd, int reader, uint16_t on_ms, uint16_t off_ms, uint8_t reps);
static void osdp_set_led_permanent(int pd, int reader, int on_color, int off_color);
static void osdp_pulse_output(int pd, uint8_t output_no, uint16_t duration_ds);
static void trigger_manual_grant(int pd);

// OSDP bus address of each PD, indexed by the `pd` argument in callbacks.
// Filled in app_main from PD_ADDRESS so the server can tell readers on
// different addresses apart.
static int g_pd_address[OSDP_NUM_PDS];

#if defined(CONFIG_OSDP_PD_MAX)
_Static_assert(OSDP_NUM_PDS <= CONFIG_OSDP_PD_MAX,
               "OSDP_NUM_PDS exceeds CONFIG_OSDP_PD_MAX -- raise it in menuconfig "
               "(Component config -> OSDP -> Maximum number of PDs)");
#endif

// Map a bus address back to its PD index (-1 if we aren't polling it).
static int pd_for_address(int address)
{
    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        if (g_pd_address[i] == address) {
            return i;
        }
    }
    return -1;
}

// Some reader firmware doesn't reliably auto-revert to the permanent LED
// state when a temporary/flash command's timer expires (observed: it just
// turns off instead). Rather than trust that behavior, we track when the
// flash should end and explicitly re-apply the idle color ourselves.
static volatile int64_t g_led_revert_at_ms[OSDP_NUM_PDS];   // one per reader

// Deadline (ms, esp_timer-based) until which a granted card scan should
// hold the unlock relay (GPIO13) HIGH. 0 = no scan-triggered unlock active
// right now. The GPIO25/26 bridge is independent of this and is re-sampled
// every loop iteration, so the two triggers combine with a simple OR.
static volatile int64_t g_relay_scan_unlock_until_ms[OSDP_NUM_PDS];   // one per reader

// Previous sampled state of the GPIO25/26 bridge, so the manual-grant
// protocol fires once per bridge event (rising edge) instead of repeating
// every 20ms loop iteration for as long as the pins stay shorted.
static bool g_bridge_prev = false;

static inline int64_t now_ms(void)
{
    return  esp_timer_get_time() / 1000;
}

// Convert a plain millisecond duration to OSDP's 100ms count units,
// rounding to the nearest count and always returning at least 1 (0 would
// mean "no beep/no timer" to the reader, which isn't the intent here).
static inline uint16_t ms_to_ds(uint32_t ms)
{
    uint32_t ds = (ms + 50) / 100;
    if (ds == 0) {
        ds = 1;
    }
    if (ds > 0xFFFF) {
        ds = 0xFFFF;
    }
    return (uint16_t)ds;
}

// Drive each local relay pin from the scan-triggered unlock windows. Each reader
// has its own window; a pin shared by several readers (entry + exit on one
// door) is HIGH while ANY of them has a window open. (The bridge itself no
// longer drives a pin directly -- see poll_bridge_trigger(), which fires the
// same simulated-grant path a real card grant uses, including this timer.)
static void unlock_relay_apply(void)
{
    int64_t now = now_ms();

    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        if (g_relay_scan_unlock_until_ms[i] != 0 && now >= g_relay_scan_unlock_until_ms[i]) {
            g_relay_scan_unlock_until_ms[i] = 0;   // this reader's window elapsed
        }
    }

    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        int pin = PD_RELAY_GPIO[i];
        if (pin < 0) {
            continue;
        }
        bool open = false;
        for (int j = 0; j < OSDP_NUM_PDS; j++) {
            if (PD_RELAY_GPIO[j] == pin && g_relay_scan_unlock_until_ms[j] != 0) {
                open = true;
            }
        }
        gpio_set_level((gpio_num_t)pin, open ? 1 : 0);
    }
}

// Sample GPIO26 and, on a rising edge (pins just bridged), kick off the
// same LED/beep/relay/door-strike sequence a granted card scan uses.
// Call this once per loop iteration.
static void poll_bridge_trigger(void)
{
    bool bridge_now = gpio_get_level(BRIDGE_SENSE_GPIO) != 0;

    if (bridge_now && !g_bridge_prev) {
        ESP_LOGI(TAG, "GPIO25/26 bridged -- simulating a granted card scan on pd=%d", BRIDGE_PD);
        trigger_manual_grant(BRIDGE_PD);
    }
    g_bridge_prev = bridge_now;
}

static int osdp_uart_recv(void *data, uint8_t *buf, int maxlen)
{
    (void)data;
    // Non-blocking: 0 ticks timeout, return whatever is already in the
    // driver's RX ring buffer (possibly nothing).
    int len = uart_read_bytes(OSDP_UART_PORT, buf, maxlen, 0);
    return (len < 0) ? 0 : len;
}

static int osdp_uart_send(void *data, uint8_t *buf, int len)
{
    (void)data;
    int written = uart_write_bytes(OSDP_UART_PORT, (const char *)buf, len);
    // uart_write_bytes queues into the driver's TX ring buffer and
    // essentially never partially fails for reasonably small OSDP frames,
    // but treat anything other than "all bytes queued" as "try again later"
    // per LibOSDP's contract (0 = retry, do not report a fatal error here).
    if (written < 0) {
        return -1;
    }
    return written;
}

static void osdp_uart_flush(void *data)
{
    (void)data;
    uart_flush(OSDP_UART_PORT);
}

// ---------------------------------------------------------------
// CP event callback -- fires on card reads, keypad events, etc.
// ---------------------------------------------------------------

static int cp_event_cb(void *arg, int pd, struct osdp_event *ev)
{
    (void)arg;

    switch (ev->type) {
    case OSDP_EVENT_CARDREAD: {
        struct osdp_event_cardread *card = &ev->cardread;
        ESP_LOGI(TAG, "CARD READ: pd=%d reader=%d format=%d bits=%d data=",
                 pd, card->reader_no, card->format, card->length);

        int data_bytes = (card->length + 7) / 8;
        char hexbuf[3 * OSDP_EVENT_CARDREAD_MAX_DATALEN + 1] = {0};
        int pos = 0;
        for (int i = 0; i < data_bytes && i < OSDP_EVENT_CARDREAD_MAX_DATALEN; i++) {
            pos += snprintf(hexbuf + pos, sizeof(hexbuf) - pos, "%02X ", card->data[i]);
        }
        ESP_LOGI(TAG, "  raw card data: %s", hexbuf);

        // Neutral "read registered" acknowledgement (amber blip). The real
        // grant/deny feedback arrives from the server via the action queue
        // and is applied in the app_main refresh loop.
        osdp_flash_led(pd, card->reader_no, OSDP_LED_COLOR_AMBER, OSDP_LED_COLOR_AMBER, 2, 2, 3);

        // Forward the raw read to the dashboard. Non-blocking: this only
        // enqueues; the network task does the HTTP so OSDP timing is safe.
        serve_home_scan_t scan = {
            .osdp_address = (pd >= 0 && pd < OSDP_NUM_PDS) ? g_pd_address[pd] : 0,
            .reader_no    = card->reader_no,
            .format       = card->format,
            .length_bits  = card->length,
            .data_len     = data_bytes,
        };
        if (scan.data_len > SERVE_HOME_MAX_CARD_BYTES) {
            scan.data_len = SERVE_HOME_MAX_CARD_BYTES;
        }
        memcpy(scan.data, card->data, scan.data_len);
        if (!serve_home_submit_scan(&scan)) {
            ESP_LOGW(TAG, "scan queue full; read dropped");
        }
        break;
    }
    case OSDP_EVENT_KEYPRESS:
        ESP_LOGI(TAG, "KEYPRESS event from pd=%d", pd);
        break;
    case OSDP_EVENT_NOTIFICATION: {
        struct osdp_notification *n = &ev->notif;
        if (n->type == OSDP_NOTIFICATION_SC_STATUS) {
            ESP_LOGI(TAG, "SC STATUS: pd=%d active=%d using_scbk_d=%d%s",
                     pd, n->sc_status.active, n->sc_status.scbk_d,
                     n->sc_status.scbk_d ?
                         "  (still on default install key -- KEYSET pending)" :
                         "  (on our permanent key -- provisioning complete)");
        } else if (n->type == OSDP_NOTIFICATION_PD_STATUS) {
            ESP_LOGI(TAG, "PD STATUS: pd=%d online=%d", pd, n->pd_status.online);
            if (n->pd_status.online && pd >= 0 && pd < OSDP_NUM_PDS) {
                // Command submission only succeeds while ONLINE, so the
                // very first attempt at boot (issued before the PD has
                // even connected) gets silently rejected. Re-apply idle
                // state here instead, every time THIS PD (re)connects,
                // using the idle color the dashboard set for this reader.
                osdp_set_led_permanent(pd, 0, serve_home_idle_color(g_pd_address[pd], 0),
                                       OSDP_LED_COLOR_NONE);
            }
        } else {
            ESP_LOGI(TAG, "Notification type %d from pd=%d", n->type, pd);
        }
        break;
    }
    default:
        ESP_LOGI(TAG, "Unhandled event type %d from pd=%d", ev->type, pd);
        break;
    }

    return 0;
}

// ---------------------------------------------------------------
// Command helpers -- LED, buzzer, output (relay/strike) control.
// Each helper takes the PD index so commands go to the right reader on the bus.
//
// IMPORTANT: osdp_cp_submit_command() queues commands BY REFERENCE, not
// by copy -- the struct must stay alive until the completion callback
// fires. A stack-allocated struct that returns before that happens
// corrupts the queue. So every helper here heap-allocates its command;
// cp_command_completion_cb() below frees it once LibOSDP is done.
// ---------------------------------------------------------------

static osdp_t *g_ctx = NULL;

static void cp_command_completion_cb(void *arg, int pd, struct osdp_cmd *cmd,
                                      enum osdp_completion_status status)
{
    (void)arg;
    if (status == OSDP_COMPLETION_FAILED) {
        ESP_LOGW(TAG, "Command id=%d to pd=%d failed (protocol/transport)", cmd->id, pd);
    }
    // OK, FLUSHED, ABORTED, and ACCEPTED all still mean "we're done with
    // this heap block" -- free it in every case per the API contract.
    free(cmd);
}

// Set the reader LED permanently to a solid color (e.g. idle-state green/red).
// Pass OSDP_LED_COLOR_NONE for off_color to just leave it solid on_color.
static void osdp_set_led_permanent(int pd, int reader, int on_color, int off_color)
{
    struct osdp_cmd *cmd = calloc(1, sizeof(*cmd));
    if (!cmd) {
        return;
    }
    cmd->id = OSDP_CMD_LED;
    cmd->led.reader = reader;
    cmd->led.led_number = 0;
    cmd->led.permanent.control_code = OSDP_CMD_LED_PERMANENT_CC_SET;
    cmd->led.permanent.on_color = on_color;
    cmd->led.permanent.off_color = off_color;
    cmd->led.permanent.on_count = 0;
    cmd->led.permanent.off_count = 0;
    cmd->led.temporary.control_code = OSDP_CMD_LED_TEMPORARY_CC_NOP;

    if (osdp_cp_submit_command(g_ctx, pd, cmd) != 0) {
        free(cmd);  // rejected: ownership never left us
    }
}

// Flash the LED temporarily (e.g. on a card scan) then it reverts to
// whatever permanent state was set before, after duration_ds * 100ms.
// Pass on_color == off_color for a solid, non-blinking presentation (the
// on/off timing is irrelevant in that case since there's nothing to
// alternate to); pass a genuinely different off_color -- e.g. the idle
// color -- for a real blink between on_color and off_color.
static void osdp_flash_led(int pd, int reader, int on_color, int off_color,
                            uint8_t on_ds, uint8_t off_ds, uint16_t duration_ds)
{
    struct osdp_cmd *cmd = calloc(1, sizeof(*cmd));
    if (!cmd) {
        return;
    }
    cmd->id = OSDP_CMD_LED;
    cmd->led.reader = reader;
    cmd->led.led_number = 0;
    cmd->led.temporary.control_code = OSDP_CMD_LED_TEMPORARY_CC_SET;
    cmd->led.temporary.on_color = on_color;
    cmd->led.temporary.off_color = off_color;
    cmd->led.temporary.on_count = on_ds;
    cmd->led.temporary.off_count = off_ds;
    cmd->led.temporary.timer_count = duration_ds;
    cmd->led.permanent.control_code = OSDP_CMD_LED_PERMANENT_CC_NOP;

    if (osdp_cp_submit_command(g_ctx, pd, cmd) != 0) {
        free(cmd);
    }
}

// Sound the reader's default beep tone once.
static void osdp_beep(int pd, int reader, uint8_t on_ds, uint8_t off_ds, uint8_t reps)
{
    struct osdp_cmd *cmd = calloc(1, sizeof(*cmd));
    if (!cmd) {
        return;
    }
    cmd->id = OSDP_CMD_BUZZER;
    cmd->buzzer.reader = reader;
    cmd->buzzer.control_code = OSDP_CMD_BUZZER_CC_DEFAULT_TONE;
    cmd->buzzer.on_count = on_ds;
    cmd->buzzer.off_count = off_ds;
    cmd->buzzer.rep_count = reps;

    if (osdp_cp_submit_command(g_ctx, pd, cmd) != 0) {
        free(cmd);
    }
}

// Pulse an output line (e.g. door strike relay wired to the reader's own
// output, if it has one) on for duration_ds * 100ms, then auto-off.
static void osdp_pulse_output(int pd, uint8_t output_no, uint16_t duration_ds)
{
    struct osdp_cmd *cmd = calloc(1, sizeof(*cmd));
    if (!cmd) {
        return;
    }
    cmd->id = OSDP_CMD_OUTPUT;
    cmd->output.output_no = output_no;
    cmd->output.control_code = OSDP_CMD_OUTPUT_CC_TEMPORARY_ON;
    cmd->output.timer_count = duration_ds;

    if (osdp_cp_submit_command(g_ctx, pd, cmd) != 0) {
        free(cmd);
    }
}

// Same as osdp_beep(), but takes the on/off pulse lengths as plain
// milliseconds (BEEP_ON_MS / BEEP_OFF_MS) instead of raw 100ms counts.
static void osdp_beep_ms(int pd, int reader, uint16_t on_ms, uint16_t off_ms, uint8_t reps)
{
    uint8_t on_ds  = (uint8_t)ms_to_ds(on_ms);
    uint8_t off_ds = (uint8_t)ms_to_ds(off_ms);
    osdp_beep(pd, reader, on_ds, off_ds, reps);
}

// Simulate a fully granted card scan on one reader -- same sequence app_main
// applies for a real serve_home grant (LED, beep, OSDP output pulse, local
// relay) -- but sourced from that reader's cached dashboard config instead of a
// server response, since this doesn't go through do_report_scan(). Used when
// GPIO25/26 are bridged. Unlock/hold/flash timing all track whatever is
// currently configured in the dashboard's settings for that reader.
static void trigger_manual_grant(int pd)
{
    if (pd < 0 || pd >= OSDP_NUM_PDS) {
        return;
    }
    int addr = g_pd_address[pd];
    int idle = serve_home_idle_color(addr, 0);

    serve_home_grant_defaults_t cfg;
    serve_home_get_grant_defaults(addr, 0, &cfg);

    if (cfg.flashing) {
        osdp_flash_led(pd, 0, cfg.led_color, idle,
                       cfg.flash_on_ds, cfg.flash_off_ds, cfg.hold_ds);
    } else {
        // Solid for the hold time (on==off color => no blink gap).
        osdp_flash_led(pd, 0, cfg.led_color, cfg.led_color,
                       (uint8_t)cfg.hold_ds, (uint8_t)cfg.hold_ds, cfg.hold_ds);
    }

    osdp_beep_ms(pd, 0, BEEP_ON_MS, BEEP_OFF_MS, 1);

    // Pulse the reader's own OSDP output (if wired to a strike) and open this
    // reader's local relay window, both for the configured unlock time.
    osdp_pulse_output(pd, 0, cfg.unlock_ds);
    g_relay_scan_unlock_until_ms[pd] = now_ms() + cfg.unlock_ds * 100;

    // Revert to this reader's idle color once the hold elapses.
    g_led_revert_at_ms[pd] = now_ms() + cfg.hold_ds * 100 + 100;
}

// ---------------------------------------------------------------
// Minimal log sink so LibOSDP's own diagnostic output goes to the
// standard ESP-IDF log rather than stderr.
// ---------------------------------------------------------------

static void osdp_log_cb(int pd, int log_level, const char *msg,
                         const char *file, unsigned long line)
{
    (void)file;
    (void)line;
    if (log_level <= OSDP_LOG_ERROR) {
        ESP_LOGE(TAG, "[pd=%d] %s", pd, msg);
    } else if (log_level <= OSDP_LOG_WARNING) {
        ESP_LOGW(TAG, "[pd=%d] %s", pd, msg);
    } else {
        ESP_LOGI(TAG, "[pd=%d] %s", pd, msg);
    }
}

void app_main(void)
{
    // ---- Bring up the RS485 UART ----
    uart_config_t uart_config = {
        .baud_rate = OSDP_UART_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_driver_install(OSDP_UART_PORT, OSDP_UART_BUF_SIZE * 2, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(OSDP_UART_PORT, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(OSDP_UART_PORT, OSDP_UART_TX_PIN, OSDP_UART_RX_PIN,
                                  UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));

    ESP_LOGI(TAG, "UART2 up: TX=%d RX=%d baud=%d", OSDP_UART_TX_PIN, OSDP_UART_RX_PIN, OSDP_UART_BAUD);

    // ---- Unlock relay output + bridge-detect drive/sense pins ----
    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        if (PD_RELAY_GPIO[i] < 0) {
            continue;
        }
        gpio_config_t relay_out_cfg = {
            .pin_bit_mask = 1ULL << PD_RELAY_GPIO[i],
            .mode         = GPIO_MODE_OUTPUT,
            .pull_up_en   = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type    = GPIO_INTR_DISABLE,
        };
        ESP_ERROR_CHECK(gpio_config(&relay_out_cfg));
        gpio_set_level((gpio_num_t)PD_RELAY_GPIO[i], 0);  // start locked
    }

    gpio_config_t bridge_drive_cfg = {
        .pin_bit_mask = 1ULL << BRIDGE_DRIVE_GPIO,
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&bridge_drive_cfg));
    gpio_set_level(BRIDGE_DRIVE_GPIO, 1);  // held high continuously

    gpio_config_t bridge_sense_cfg = {
        .pin_bit_mask = 1ULL << BRIDGE_SENSE_GPIO,
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,  // reads LOW until bridged to 25
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&bridge_sense_cfg));

    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        ESP_LOGI(TAG, "reader pd=%d: OSDP address %d, local relay GPIO %d",
                 i, PD_ADDRESS[i], PD_RELAY_GPIO[i]);
    }
    ESP_LOGI(TAG, "bridge drive/sense GPIO=%d/%d (simulates a grant on pd=%d)",
             BRIDGE_DRIVE_GPIO, BRIDGE_SENSE_GPIO, BRIDGE_PD);

    // Route LibOSDP's own log output before setup, per its API contract.
    osdp_set_log_callback(osdp_log_cb);

    // ---- Describe every reader (PD) on the shared RS485 bus ----
    static osdp_pd_info_t pd_info[OSDP_NUM_PDS];
    static char pd_names[OSDP_NUM_PDS][16];
    memset(pd_info, 0, sizeof(pd_info));
    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        snprintf(pd_names[i], sizeof(pd_names[i]), "hid-r10-%d", PD_ADDRESS[i]);
        pd_info[i].name       = pd_names[i];
        pd_info[i].baud_rate  = OSDP_UART_BAUD;
        pd_info[i].address    = PD_ADDRESS[i];   // must match the address set on the reader
        pd_info[i].flags      = OSDP_FLAG_INSTALL_MODE | OSDP_FLAG_ENABLE_NOTIFICATION;
        pd_info[i].cap        = NULL;   // only used in PD mode
        // Target permanent key. LibOSDP will try this first; if the reader
        // doesn't know it yet (fresh install), it automatically falls back
        // to the well-known default install key (SCBK-D) -- which the R10
        // accepts because you enabled Install Mode on it -- establishes SC,
        // then pushes r10_scbk via KEYSET and switches over automatically.
        // (All readers share this one bench key; use a per-reader key for a
        // real deployment.)
        pd_info[i].scbk       = r10_scbk;

        // Record each PD's bus address so card reads can be attributed to the
        // right reader server-side.
        g_pd_address[i] = pd_info[i].address;
    }

    // ---- Channel: how LibOSDP talks to the UART ----
    struct osdp_channel channel = {
        .data  = NULL,
        .recv  = osdp_uart_recv,
        .send  = osdp_uart_send,
        .flush = osdp_uart_flush,
        .close = NULL,
    };

    osdp_t *ctx = osdp_cp_setup(&channel, OSDP_NUM_PDS, pd_info);
    if (ctx == NULL) {
        ESP_LOGE(TAG, "osdp_cp_setup() failed -- halting");
        return;
    }
    g_ctx = ctx;

    osdp_cp_set_event_callback(ctx, cp_event_cb, NULL);
    osdp_cp_set_command_completion_callback(ctx, cp_command_completion_cb, NULL);

    // Bring up WiFi + the serve-home network task (enroll, heartbeat, scan
    // reporting). Non-blocking; runs in its own task.
    serve_home_start();

    ESP_LOGI(TAG, "OSDP CP context ready, entering refresh loop");

    // Best-effort idle color at boot -- may be silently rejected if the
    // PD isn't ONLINE yet. The reliable path is the PD_STATUS online=1
    // handler in cp_event_cb, which re-applies this on every connect.
    for (int i = 0; i < OSDP_NUM_PDS; i++) {
        osdp_set_led_permanent(i, 0, serve_home_idle_color(g_pd_address[i], 0), OSDP_LED_COLOR_NONE);
    }

    // LibOSDP requires osdp_cp_refresh() at least every 50ms to meet
    // OSDP timing requirements. 20ms gives comfortable margin.
    while (1) {
        osdp_cp_refresh(ctx);

        // Apply any access decision the server produced for a recent read.
        serve_home_action_t act;
        if (serve_home_poll_action(&act)) {
            int pd = pd_for_address(act.osdp_address);
            if (pd < 0) {
                ESP_LOGW(TAG, "decision for unknown OSDP address %d ignored", act.osdp_address);
            } else {
                int idle = serve_home_idle_color(act.osdp_address, act.reader_no);
                if (act.flashing) {
                    // Genuinely alternate the grant/deny color against the idle
                    // color, using the dashboard's flash-on/flash-off timing,
                    // for the full hold time.
                    osdp_flash_led(pd, act.reader_no, act.led_color, idle,
                                   act.flash_on_ds, act.flash_off_ds, act.hold_ds);
                } else {
                    // Solid for the hold time (on==off color => no blink gap).
                    osdp_flash_led(pd, act.reader_no, act.led_color, act.led_color,
                                   act.hold_ds, act.hold_ds, act.hold_ds);
                }
                if (act.beep) {
                    osdp_beep_ms(pd, act.reader_no, BEEP_ON_MS, BEEP_OFF_MS, act.grant ? 1 : 3);
                }
                if (act.grant && act.unlock_ds > 0) {
                    // Pulse the door strike via THIS reader's own OSDP output...
                    osdp_pulse_output(pd, 0, act.unlock_ds);
                    // ...and independently open this reader's local relay
                    // window (PD_RELAY_GPIO) for the same duration.
                    g_relay_scan_unlock_until_ms[pd] = now_ms() + act.unlock_ds * 100;
                }
                // Revert THIS reader to its idle color once the hold elapses.
                g_led_revert_at_ms[pd] = now_ms() + act.hold_ds * 100 + 100;
            }
        }

        for (int i = 0; i < OSDP_NUM_PDS; i++) {
            if (g_led_revert_at_ms[i] != 0 && now_ms() >= g_led_revert_at_ms[i]) {
                g_led_revert_at_ms[i] = 0;
                osdp_set_led_permanent(i, 0, serve_home_idle_color(g_pd_address[i], 0),
                                       OSDP_LED_COLOR_NONE);
            }
        }

        // Rising-edge check on the GPIO25/26 bridge -- fires a simulated
        // grant (LED/beep/relay/strike) once per bridge event.
        poll_bridge_trigger();

        // Drive GPIO13 from whichever grant (real or simulated) most
        // recently opened an unlock window.
        unlock_relay_apply();

        vTaskDelay(pdMS_TO_TICKS(20));
    }
}