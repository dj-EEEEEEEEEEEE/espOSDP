/*
 * serve_home.h -- "serve home" client for the OSDP control panel.
 *
 * Connects the ESP32 CP to the OSDP XCS dashboard over WiFi and HTTP:
 *   1. joins WiFi (STA),
 *   2. enrolls with the controller's enroll key -> receives a device token,
 *   3. heartbeats periodically (reporting telemetry, learning the config
 *      version), and
 *   4. reports every card read to the server and hands back the access
 *      decision (LED color/pattern, beep, door-strike unlock) for the OSDP
 *      task to apply.
 *
 * Threading model (important):
 *   LibOSDP's osdp_cp_refresh() must run at least every 50 ms, so we must
 *   NEVER block the OSDP task on network I/O. Instead:
 *
 *     cp_event_cb (OSDP task) --serve_home_submit_scan()--> [scan queue]
 *         -> serve_home_task (its own task) does the blocking HTTP POST
 *         -> [action queue] --serve_home_poll_action()--> app_main loop
 *            (OSDP task) applies the LED/buzzer/output commands.
 *
 *   Keeping every osdp_cp_* call on the single OSDP task avoids racing
 *   LibOSDP from two tasks.
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SERVE_HOME_MAX_CARD_BYTES 16

/* Max readers (PDs) whose dashboard config we keep. Matches CONFIG_OSDP_PD_MAX
 * or larger; extra readers from the server are ignored with a warning. */
#define SERVE_HOME_MAX_READERS    8

/* One decoded card read, handed from the OSDP callback to the network task. */
typedef struct {
    int     osdp_address;   /* bus address of the PD the read came from     */
    int     reader_no;      /* reader index within that PD (cardread.reader_no) */
    int     format;         /* osdp_event_cardread format enum              */
    int     length_bits;    /* number of bits in the raw read               */
    uint8_t data[SERVE_HOME_MAX_CARD_BYTES]; /* raw card bytes, MSB-first   */
    int     data_len;       /* valid bytes in data[]                        */
} serve_home_scan_t;

/* The action the server told us to take, handed back to the OSDP task. */
typedef struct {
    bool     valid;
    int      osdp_address;  /* bus address of the PD this decision is for   */
    int      reader_no;     /* reader index within that PD                  */
    bool     grant;
    int      led_color;     /* enum osdp_led_color_e value (server 0..7)     */
    int      idle_color;    /* color to revert to after the hold            */
    bool     flashing;      /* true = blink pattern, false = solid          */
    uint16_t hold_ds;       /* how long to show led_color, in deciseconds   */
    uint8_t  flash_on_ds;
    uint8_t  flash_off_ds;
    bool     beep;
    uint16_t unlock_ds;     /* door-strike relay pulse (ds); 0 = no pulse    */
} serve_home_action_t;

/*
 * A reader's configured "grant" presentation and unlock duration, as last
 * fetched from the dashboard (the readers[] entry whose osdpAddress/readerNo
 * match) -- same shape of data a real per-scan grant carries in
 * serve_home_action_t, cached here for triggers that don't go through
 * do_report_scan() (e.g. a manual override button). Returns sane defaults
 * for a reader the dashboard doesn't know about, or before the first fetch.
 */
typedef struct {
    int      led_color;     /* enum osdp_led_color_e value (server 0..7)     */
    bool     flashing;      /* true = blink pattern, false = solid          */
    uint16_t hold_ds;       /* how long to show led_color, in deciseconds   */
    uint8_t  flash_on_ds;
    uint8_t  flash_off_ds;
    uint16_t unlock_ds;     /* door-strike relay pulse (ds); 0 = no pulse    */
} serve_home_grant_defaults_t;

void serve_home_get_grant_defaults(int osdp_address, int reader_no,
                                   serve_home_grant_defaults_t *out);

/*
 * Start WiFi and the serve-home network task. Call once from app_main after
 * osdp_cp_setup(). Non-blocking; connection and enrollment happen in the
 * background task. Safe to call before the PD is online.
 */
void serve_home_start(void);

/*
 * Enqueue a card read for the network task. Called from cp_event_cb on the
 * OSDP task. Non-blocking. Returns false if the queue was full (read dropped
 * rather than stalling OSDP timing).
 */
bool serve_home_submit_scan(const serve_home_scan_t *scan);

/*
 * Non-blocking check for a decision the network task has produced. Called from
 * the app_main refresh loop each iteration. Returns true and fills *out when
 * an action is ready.
 */
bool serve_home_poll_action(serve_home_action_t *out);

/*
 * The idle LED color most recently pushed by the server's config for the
 * reader at this OSDP address / reader number (enum osdp_led_color_e value).
 * Returns a sane default (blue) for an unknown reader or before the first
 * config fetch. Lets the OSDP task revert each reader to ITS idle color.
 */
int serve_home_idle_color(int osdp_address, int reader_no);

/* True once enrollment has produced a device token. */
bool serve_home_is_enrolled(void);

#ifdef __cplusplus
}
#endif