/*
 * serve_home_config.h -- edit these for your bench / deployment.
 *
 * Everything the serve-home client needs to reach your dashboard. For a real
 * deployment, prefer provisioning WiFi credentials and the enroll key into NVS
 * (see serve_home.c: values found in NVS override the defaults below) rather
 * than compiling secrets into the image.
 */

#pragma once

/* ---- WiFi (STA) ---- */
#define SERVE_HOME_WIFI_SSID      "SpectrumSetup-86"
#define SERVE_HOME_WIFI_PASSWORD  "quoteagency125"

/* ---- Dashboard ----
 * Base URL of the OSDP XCS server, no trailing slash. Shown in the dashboard
 * under User Config -> Firmware connection, and on the controller page.
 * Use http:// for a plain bench server; for TLS see the note in serve_home.c.
 */
#define SERVE_HOME_URL            "http://192.168.1.156:3000"

/* The controller's enroll key, from the controller detail page in the
 * dashboard ("Serve-home provisioning" card). Rotating the key there requires
 * re-flashing this (or clearing NVS) so the device re-enrolls. */
#define SERVE_HOME_ENROLL_KEY     "4bd395416bccbe1bffa382d563003134"

/* ---- Timing ---- */
#define SERVE_HOME_HEARTBEAT_SEC  15   /* how often to heartbeat            */
#define SERVE_HOME_HTTP_TIMEOUT_MS 8000

/* Bit format to tell the server how to decode the raw read (26 or 35). The
 * HID R10 on the bench is standard 26-bit H10301. */
#define SERVE_HOME_BIT_FORMAT     26
