idf_component_register(
    SRCS "main.c" "serve_home.c"
    INCLUDE_DIRS "."
    REQUIRES mbedtls libosdp esp_driver_uart esp_driver_gpio esp_timer
             esp_wifi esp_event esp_netif esp_http_client nvs_flash
)