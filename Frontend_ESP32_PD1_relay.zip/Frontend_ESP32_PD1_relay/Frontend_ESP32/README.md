# OSDP CP test app (ESP-IDF + official LibOSDP)

This replaces the Arduino IDE hand-rolled OSDP sketch with the real,
spec-compliant LibOSDP library (https://github.com/osdp-dev/libosdp),
via its official ESP-IDF component.

## Why this is a toolchain switch, not just a library swap

LibOSDP does **not** have an Arduino IDE library package. It ships as a
CMake-based C library with an official ESP-IDF component definition
(`esp-idf/` + `idf_component.yml` in the repo). Using it means building
with ESP-IDF's own tooling (`idf.py`) instead of the Arduino IDE.

## One-time setup

1. Install ESP-IDF (v5.0+) if you haven't already. Espressif's guide:
   https://docs.espressif.com/projects/esp-idf/en/stable/esp32/get-started/index.html
   (VS Code extension is the easiest path if you want a GUI similar to
   Arduino IDE; the command-line `idf.py` works the same either way.)

2. From this project's root folder, pull in the LibOSDP dependency:
   ```
   idf.py add-dependency "osdp-dev/libosdp"
   ```
   This is already reflected in `main/idf_component.yml`, so running
   `idf.py build` the first time will fetch it automatically via the
   ESP Component Registry -- no manual submodule needed.

## Build and flash

```
idf.py set-target esp32
idf.py build
idf.py -p <YOUR_SERIAL_PORT> flash monitor
```
(`idf.py monitor` gives you the live log output, similar to Arduino's
Serial Monitor. Ctrl+] to exit.)

## What this does

- Brings up UART2 on GPIO 14 (RX, wired to the RS485 board's TX) and
  GPIO 27 (TX, wired to the RS485 board's RX) at OSDP's default 9600 baud
- Registers one PD (the R10) at OSDP address 0, **no secure channel yet**
  (`scbk = NULL`) -- plaintext CRC-16 mode, which is LibOSDP's default and
  is a real implementation of the modern OSDP spec (unlike the checksum-only
  hand-rolled version we tested offline earlier)
- Calls `osdp_cp_refresh()` every 20ms in a loop, which internally handles
  polling, sequencing, and timing per spec
- Logs every card read via the event callback, printing reader number,
  card format, bit length, and raw card data bytes

## Expected behavior

On boot you should see `UART2 up: ...` followed by LibOSDP's own internal
log lines as it starts polling the R10. If wiring/baud/address are correct,
you should see it settle into a steady poll/ack cycle. Scanning a card
should produce a `CARD READ:` log line with the card's raw data.

## Next steps once basic polling works

- If the R10 requires secure channel (many HID readers do once provisioned),
  set `pd_info[0].scbk` to the 16-byte Secure Channel Base Key instead of NULL
- If baud/address were changed from defaults by a previous installer, update
  `OSDP_UART_BAUD` and `pd_info[0].address` to match
- Consider setting `CONFIG_OSDP_PD_MAX=1` in `idf.py menuconfig` (under
  `Component config -> Open Supervised Device Protocol (OSDP)`) since this
  app only ever talks to one PD -- saves RAM vs. the default of 126
